const knex = require("../database/db_config")


exports.getClientData = async function (req, res) {
   const id = req.user.id
   try {
      const [client] = await knex("clients").where({ id }).returning("*")
      if (!client) return res.json({ Error: "Клиент не найден" })

      return res.status(200).json({success: true, info: client})
   } catch (error) {
      console.log(error)
   }
}

exports.getClients = async function (_, res) {
   try {
      const clients = await knex("clients").select("*")
      if (!clients) {
         return res.send({ Error: "Something went wrong" })
      }

      return res.status(200).send(clients)
   } catch (error) {
      console.log(error)
   }
}

exports.requestEmailConfirmation = async function (req, res) {
   // TODO: Generate confirmation code
   const confirmationCode = "0000";

   try {
      const id = req.params.id
      const record = await knex("clients")
         .where({ id });

      if (!record) {
         res.status(401).body({ msg: "Error, user not found" })
      }

      if (record.emailIsConfirmed) {
         res.status(401).body({ msg: "Email is already confirmed" })
      }

      await knex("clients")
         .update({ email_confirmation_code: confirmationCode })
         .where({ id });

      // TODO: Send email

      return { msg: "Hello" };
   } catch (error) {
      console.log(error)
   }
}