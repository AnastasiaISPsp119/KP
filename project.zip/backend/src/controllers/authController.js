const knex = require("../database/db_config")
const { validationResult } = require("express-validator")
const { hash, compare } = require("bcryptjs")
const { genAccessToken } = require("../utilities/tokenGen")

exports.signUp = async function (req, res) {
   const errors = validationResult(req)
   const { username, profile_pic_url, email, phone, password } = req.body
   try {
      if (!errors.isEmpty()) {
         return res.status(401).json({
            success: false,
            msg: "Ошибка при регистрации",
            errors
         })
      }

      const [candidate] = await knex("clients")
         .where({ username }).orWhere({ email }).returning("*")
      if (candidate) {
         return res.json({ success: false, msg: "Profile already exists" })
      }

      const hashedPasswd = await hash(password, 10)
      const client = await knex("clients").insert({
         username,
         profile_pic_url,
         email,
         phone,
         password: hashedPasswd
      }).returning("*")

      const accessToken = genAccessToken(client.id, client.role)

      return res.status(201).json({ success: true, token: accessToken })
   } catch (error) {
      console.log(error)
      return res.status(500).json({ success: false, msg: "Server error" })
   }
}

exports.logIn = async function (req, res) {
   const { login, password } = req.body
   try {
      const [client] = await knex("clients").where({ username: login }).orWhere({ email: login }).returning("*")
      if (!client)
         return res.json({ success: false, msg: "Client not found" })

      const comparedPasswd = await compare(password, client.password)
      if (!comparedPasswd)
         return res.json({ success: false, msg: "wrong credentials" })

      const accessToken = genAccessToken(client.id, client.role)

      return res.status(200).json({ success: true, token: accessToken })
   } catch (error) {
      console.log(error)
      return res.status(500).json({ success: false, msg: "Server error" })
   }
}