const knex = require("../database/db_config")
const { validationResult } = require("express-validator")


exports.addProduct = async function (req, res) {
   const errors = validationResult(req)
   const { title, product_pic_url, description, price, amount } = req.body

   try {
      if (!errors.isEmpty()) {
         return res.status(400).json({
            message: "Ошибка при добавлении продукта",
            errors
         })
      }

      await knex("products").insert({
         title,
         product_pic_url,
         description,
         price,
         amount
      })

      return res.status(201).json({ success: true, msg: "product is created" })
   } catch (error) {
      console.log(error)
      return res.status(503).json({ msg: "Server error" })
   }
}

exports.updateProduct = async function (req, res) {
   const errors = validationResult(req)
   const { title, product_pic_url, description, price, amount } = req.body
   const id = req.params.id

   try {
      if (!errors.isEmpty()) {
         return res.status(400).json({
            msg: "Ошибка при добавлении продукта",
            errors
         })
      }
      const [product] = await knex("products").where({ id }).returning("*")

      await knex("products").where({ id: product.id }).update({
         title: title || product.title,
         product_pic_url: product_pic_url || product.product_pic_url,
         description: description || product.description,
         price: price || product.price,
         amount: amount || product.amount
      })

      return res.status(201).json({ success: true, msg: "product is updated" })
   } catch (error) {
      console.log(error)
      return res.status(503).json({ success: false, msg: "Server error" })
   }
}

exports.deleteProduct = async function (req, res) {
   const id = req.params.id

   try {
      await knex("products").where({ id }).delete()

      return res.status(200).json({ success: true, msg: "record deleted" })
   } catch (error) {
      console.log(error)
      return res.status(503).json({ success: false, msg: "Server error" })
   }
}

exports.getProducts = async function (_, res) {
   try {
      const products = await knex("products").select("*")

      return res.status(200).json({ success: true, products })
   } catch (error) {
      console.log(error)
      return res.status(503).json({ success: false, msg: "Server error" })
   }
}

exports.getProduct = async function (req, res) {
   const id = req.params.id

   try {
      const [product] = await knex("products").where({ id })

      return res.status(200).json({ success: true, product })
   } catch (error) {
      console.log(error)
      return res.status(503).json({ success: false, msg: "Server error" })
   }
}
