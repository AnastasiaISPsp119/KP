const knex = require("../database/db_config")

exports.createOrder = async function (req, res) {
   const { order_details, delivery_address } = req.body
   const { id } = req.user

   try {
      await knex("orders").insert({
         order_details: JSON.stringify(order_details),
         delivery_address,
         client_id: id
      })

      return res.status(201).json({ success: true, msg: "order is created" })
   } catch (error) {
      console.log(error)
      return res.status(503).json({ success: false, msg: "Server error" })
   }
}


exports.getOrders = async function (_, res) {
   try {
      const orders = await knex("orders").select("*")

      return res.status(200).json({ success: true, orders })
   } catch (error) {
      console.log(error)
      return res.status(503).json({ success: false, msg: "Server error" })
   }
}

exports.getOrder = async function (req, res) {
   const id = req.params.id

   try {
      const client = await knex("clients").where({ id }).select("*")
      const orders = await knex("orders").where(client.id).select("*")

      return res.status(200).json({ success: true, orders })
   } catch (error) {
      console.log(error)
      return res.status(503).json({ success: false, msg: "Server error" })
   }
}