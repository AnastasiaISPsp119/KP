const jwt = require("jsonwebtoken")
require('dotenv').config()

exports.genAccessToken = function(id, role) {
   const payload = {id, role}
   
   return jwt.sign(payload, process.env.JWT_KEY, { expiresIn: "1h" })
}