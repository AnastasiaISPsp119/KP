/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.up = async function (knex) {
   await knex.schema
      .createTable("clients", table => {
         table.increments("id");
         table.string('username').notNullable().unique()
         table.string('profile_pic_url').notNullable().defaultTo("not set")
         table.string("email").notNullable().unique()
         table.boolean("emailIsConfirmed").notNullable().defaultTo(false)
         table.string("phone")
         table.string("password").notNullable()
         table.string("email_confirmation_code", 6);
         table.enu("role", ["user", "editor", "admin"]).notNullable()
            .defaultTo("user");
         table.timestamps(true, true)
      })

      .createTable("orders", table => {
         table.increments("id");
         table.enu("status", ["processing", "delivery", "done"]).notNullable()
            .defaultTo("processing");
         table.json("order_details").notNullable()
         table.string("delivery_address").notNullable().defaultTo("not set")
         table.integer("client_id").notNullable()
         table.foreign("client_id").references("clients.id")
            .onDelete("restrict").onUpdate("cascade");
      })

      .createTable("products", table => {
         table.increments("id");
         table.string("title").notNullable()
         table.string("product_pic_url").notNullable()
         table.string("description").notNullable()
         table.integer("price").notNullable()
         table.integer("amount").notNullable()
      
      })

      .createTable("wish_lists", table => {
         table.integer("client_id")
         table.foreign("client_id").references("clients.id")
            .onDelete("restrict").onUpdate("cascade");
         table.integer("product_id")
         table.foreign("product_id").references("products.id")
            .onDelete("restrict").onUpdate("cascade");
      })
};

/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> }
 */
exports.down = async function (knex) {
   await knex.schema
      .dropTableIfExists("wish_lists")
      .dropTableIfExists("orders")
      .dropTableIfExists("clients")
      .dropTableIfExists("products")
};
