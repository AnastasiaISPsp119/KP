/**
 * @param { import("knex").Knex } knex
 * @returns { Promise<void> } 
 */
exports.seed = async function(knex) {
  // Deletes ALL existing entries
  await knex('clients').del()
  await knex('clients').insert([
    {username: "simpleUser", email: 'simpleUser@gmail.com', password: "123456"},
    {username: "HoobaBooba", email: 'HoobaBooba@proton.me', password: "qwerty"},
    {username: "Call-Me-Maybe", email: 'CallMeMaybe@mail.ru', password: "call911pls"},
  ]);
};
