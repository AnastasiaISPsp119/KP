const { createOrder, getOrders, getOrder } = require("../controllers/ordersController")
const checkAuth = require("../middlewares/authMiddleware")

const express = require("express"),
   router = express.Router()


router.post("/createOrder", checkAuth, createOrder)

router.get("/getOrders", checkAuth, getOrders)
router.get("/getOrder/:id", checkAuth, getOrder)


module.exports = router