const { getClients, getClientData } = require("../controllers/clientsController")
const checkAuth = require("../middlewares/authMiddleware")

const { check } = require("express-validator"),
   express = require("express"),
   router = express.Router()


// TODO: write controller for clients
router.get("/getClient", checkAuth, getClientData)
router.get("/getClients", getClients)

module.exports = router
