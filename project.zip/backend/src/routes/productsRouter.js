const { addProduct, deleteProduct, updateProduct, getProducts, getProduct } = require("../controllers/productsController")

const express = require("express"),
   router = express.Router()


router.post("/addProduct", addProduct)
router.post("/updateProduct/:id", updateProduct)
router.post("/deleteProduct/:id", deleteProduct)
router.get("/getProducts", getProducts)
router.get("/getProduct/:id", getProduct)

module.exports = router