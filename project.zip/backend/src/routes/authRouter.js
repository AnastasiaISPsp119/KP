const { signUp, logIn } = require("../controllers/authController")

const { check } = require("express-validator"),
   express = require("express"),
   router = express.Router()


router.post("/signup",
   check("username", "Имя пользователя должно быть введено").notEmpty(),
   check("email", "Почта должна быть заполнена").notEmpty(),
   check("password", "Пароль должен быть большей 4-х символов").isLength(4),
   signUp)

router.post("/login", logIn)

module.exports = router