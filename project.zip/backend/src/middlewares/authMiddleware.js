const jwt = require("jsonwebtoken")
require("dotenv").config()

function checkAuth(req, res, next) {
   if (req.method === "OPTIONS") {
      next()
   }
   try {
      if (req.headers.authorization === undefined)
         return res.status(401).json({ success: false, msg: "not authorized-1" })

      const token = req.headers.authorization
      if (!token)
         return res.status(401).json({ success: false, msg: "not authorized-2" })

      const decodedData = jwt.verify(token, process.env.JWT_KEY)
      if (!decodedData)
         return res.status(401).json({ success: false, msg: "not authorized-3" })
      req.user = decodedData

      next()
   } catch (err) {
      console.log(err)
      return res.status(503).json({ success: false, msg: "Server error" })
   }
}

module.exports = checkAuth