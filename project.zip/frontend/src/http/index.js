import axios from "axios"
import { useToken } from "../hooks/useToken"

const API_URL = "http://localhost:8080/api"

const $api = axios.create({
   withCredentials: true,
   baseURL: API_URL
})



$api.interceptors.request.use(config => {
   config.headers.Authorization = useToken()
   return config
})

export default $api