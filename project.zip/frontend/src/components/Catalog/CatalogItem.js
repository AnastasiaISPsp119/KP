import { Button, Card } from "react-bootstrap"
import { CartPlus, Heart } from 'react-bootstrap-icons';
import "../../styles/Catalog.css" 

function CatalogItem(props) {
   const {
      product
   } = props
   return (
      <Card className="d-flex flex-column m-3" style={{ width: '15rem' }}>
         <Card.Img variant="top" src={product.product_pic_url} />
         <Card.Body>
            <Card.Title className="fw-bold">{product.name}</Card.Title>
            <Card.Text >
               <p>{product.description}</p>
               <p>Цена: <b>{product.price}</b> гривень</p>
               <span className="mb-auto">Осталось на складе: <b>{product.amount}</b> шт.</span>
            </Card.Text>
            <Button className="card me-3" >
              <CartPlus size={20}/> в корзину 
            </Button>

            <Button className="card ms-3">
              <Heart size={20}/>
            </Button>
         </Card.Body>
      </Card>
   )
}

export default CatalogItem