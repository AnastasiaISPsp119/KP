import { Navbar, Nav, Container, Button } from "react-bootstrap"
import { Link } from "react-router-dom"
import { logout } from "../services/authService"
import logo from "../assets/images/logo-w.png"
import {PersonCircle, Cart} from "react-bootstrap-icons"
import styles from "../styles/Header.module.css"
function Header() {
   const token = localStorage.getItem("token")

   return (
      <Navbar collapseOnSelect expand="lg" bg="black" variant="dark">
         <Container>
            <Navbar.Brand as={Link} to="/">
               <img src={logo} style={{ maxHeight: 50 }} />
            </Navbar.Brand>
            <Navbar.Toggle aria-controls="responsive-navbar-nav" />
            <Navbar.Collapse id="responsive-navbar-nav">
               <Nav className="ms-auto">
                  <Nav.Link className={styles.navLink} as={Link} to="/">Главная</Nav.Link>
                  <Nav.Link className={styles.navLink} as={Link} to="/catalog">Товары</Nav.Link>
                  <Nav.Link className={styles.navLink} as={Link} to="/about">О нас</Nav.Link>
               </Nav>
               {
                  !token ?
                     (
                        <Nav className="ms-5">
                           <Button className={styles.btn} as={Link} to="/login">Log in</Button>
                           <Button className={styles.btn} as={Link} to="/signup">Sign up</Button>
                        </Nav>
                     ) : (
                        <Nav className="ms-5">
                           <Nav.Link className={styles.navLink} as={Link} to="/cart">
                              <Cart size={45}/>
                           </Nav.Link>
                           <Nav.Link className={styles.navLink} as={Link} to="/profile">
                              <PersonCircle size={45}/>
                           </Nav.Link>
                           <Button className={styles.btn} onClick={logout}>Log out</Button>
                        </Nav>
                     )
               }
            </Navbar.Collapse>
         </Container>
      </Navbar>
   )
}

export default Header