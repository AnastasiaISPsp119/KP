import React from 'react'
import { Container, Nav, Navbar } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import styles from "../styles/Footer.module.css"

function Footer() {
   return (
      <Navbar className='mt-auto' collapseOnSelect expand="lg" bg="black" variant="dark">
         <Container style={{ justifyContent: "center" }}>
            <span className='me-4' style={{ color: "white", fontSize: "large" }}>
               &#169; Всё для маникюря, 2022
            </span>
            <Nav>
               <Nav.Link className={styles.navLink} as={Link} to="/">Главная</Nav.Link>
               <Nav.Link className={styles.navLink} as={Link} to="/catalog">Товары</Nav.Link>
               <Nav.Link className={styles.navLink} as={Link} to="/about">О нас</Nav.Link>
            </Nav>
         </Container>
      </Navbar>
   )
}

export default Footer