import $api from "../http";

export async function getClientData() {
   return $api.get("/clients/getClient", )
}