import $api from "../http";

export async function getProducts() {
   return $api.get("/products/getProducts")
}

export async function addProduct(title, product_pic_url, description, price, amount) {
   return $api.post("/products/addProduct", { title, product_pic_url, description, price, amount })
}