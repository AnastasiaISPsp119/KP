import $api from "../http";

export async function signin(login, password) {
   return $api.post("/login", { login, password })
}

export async function signup(username, email, password) {
   return $api.post("/signup", { username, email, password })
}

export async function logout() {
   localStorage.removeItem("token")
} 