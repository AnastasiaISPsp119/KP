import { Container } from "react-bootstrap";
import { Route, Routes } from "react-router-dom";
import './App.css';
import Footer from "./components/Footer";
import Header from './components/Header';
import About from "./pages/About";
import Cart from "./pages/Cart";
import Catalog from './pages/Catalog';
import Login from "./pages/Login";
import Main from './pages/Main';
import Profile from "./pages/Profile";
import Signup from "./pages/Signup";

function App() {
  return (
    <div className="App d-flex flex-column" style={{ height: "inherit" }}>
      <Header />
      <Container className="d-flex w-90 ">
        <Routes className="mb-auto">
          <Route path='/' element={<Main />} />
          <Route path='/catalog' element={<Catalog />} />
          <Route path='/about' element={<About />} />
          <Route path='/login' element={<Login />} />
          <Route path='/signup' element={<Signup />} />
          <Route path='/profile' element={<Profile />} />
          <Route path='/cart' element={<Cart />} />
        </Routes>
      </Container>
      <Footer />
    </div>
  );
}

export default App;
