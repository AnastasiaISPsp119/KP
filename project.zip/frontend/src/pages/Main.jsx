import { Container, Image, Stack } from "react-bootstrap"
import mainImage from "../assets/images/main.jpg"
function Main() {
  return (
    <>
      <Stack className="h-100" direction="horizontal" gap={3}>
        <Container className="w-25" style={{align: "center"}}>
          <h1>Интернет-магазин</h1>
          <p className="fs-3">всё для маникюра</p>
        </Container>
        <div className="w-auto">
          <Image style={{height: 800}} src={mainImage} alt="main jpg" responsive/>
        </div>
      </Stack>
    </>
  )
}

export default Main