import { Container } from "react-bootstrap"
import logo from "../assets/images/logo-b.png"
import styles from "../styles/About.module.css"

function About() {
  return (
    <>
      <Container className="d-flex flex-column my-5" style={{ alignItems: "center" }}>
        <img src={logo} style={{ maxWidth: 208, maxHeight: 132 }} />
        <h1>О нас</h1>
        <Container className="w-75" style={{fontSize: "x-large"}}>
          <p>
            Мы дарим все для красоты и женственности.
            Мы тщательно следим за последними новинками, предлагаем большой выбор материалов для ногтей.
          </p>
          <p>
            Невероятно большое количество положительных отзывов о работе нашей команды побуждает нас держать
            свою марку, продолжать совершенствоваться и реализовывать Ваши пожелания для того, чтобы стать для
            Вас лучшим магазином женских радостей.
          </p>
          <p>
            Просто добавьте необходимые товары в «Корзину», заполните данные для отправления посылки.
          </p>
        </Container>
      </Container>
    </>
  )
}

export default About