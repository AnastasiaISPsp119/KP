import { useEffect, useState } from "react"
import { Card, Container } from "react-bootstrap"
import { getClientData } from "../services/userService"


function Profile() {
   const [clientData, setClientData] = useState([])

   useEffect(() => {
      getClientData().then(response => setClientData(response.data.info))
   }, [])

   return (
      <>
         <Container className="d-flex flex-column" style={{ alignItems: "center" }}>
            <h1>Это ваш профиль</h1>
            <Card className="w-100" style={{height: "25rem"}}>
               <Card.Body>
                  <Card.Title>
                     <b>Username:</b> {clientData.username}
                  </Card.Title>
                  <Card.Subtitle className="mb-2 text-muted">{clientData.email}</Card.Subtitle>
                  <Card.Text>
                     Здесь будут отображаться ваши заказы. Они появятся автоматически.
                  </Card.Text>
               </Card.Body>
            </Card>
         </Container>
      </>
   )
}

export default Profile