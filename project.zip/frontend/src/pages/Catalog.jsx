import { useEffect, useState } from "react"
import { Button, Container, Form } from "react-bootstrap"
import CatalogItem from "../components/Catalog/CatalogItem"
import { addProduct, getProducts } from "../services/catalogService"
import { getClientData } from "../services/userService"

function Catalog() {

  const [products, setProducts] = useState([])
  const [clientData, setClientData] = useState([])

  const [title, setTitle] = useState()
  const [product_pic_url, setProductPicUrl] = useState()
  const [description, setDescription] = useState()
  const [price, setPrice] = useState()
  const [amount, setAmount] = useState()

  useEffect(() => {
    getClientData().then(response => setClientData(response.data.info))
  }, [])

  useEffect(() => {
    getProducts().then(response => setProducts(response.data.products))
  }, [])

  function addNewProduct(event) {
    event.preventDefault();
    event.stopPropagation();

    addProduct(title, product_pic_url, description, price, amount)
    .then(response => event(response.data.msg))

 }

  return (
    <>
      <Container className="d-flex flex-column" style={{ alignItems: "center" }}>
        <h1>Каталог</h1>
        <Container className="d-flex flex-wrap" style={{ justifyContent: "center" }}>
          {
            products ? products.map((product) => {
              return <CatalogItem product={product} />
            }) : <h3>Товары в каталоге отсутвуют</h3>
          }
        </Container>

        {
          clientData.role === "admin"
          &&
          <Form onSubmit={addNewProduct}>
            <h1>Добоваление товара</h1>
            <Form.Group className="mb-3">
              <Form.Label>Наименование</Form.Label>
              <Form.Control required type="text" placeholder="Введите наименование"
                value={title}
                onChange={e => { setTitle(e.target.value) }} />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Ссылка на изображение</Form.Label>
              <Form.Control required type="text" placeholder="Ссылка на изображение"
                value={product_pic_url}
                onChange={e => { setProductPicUrl(e.target.value) }} />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Описание</Form.Label>
              <Form.Control required type="text" placeholder="Описание"
                value={description}
                onChange={e => { setDescription(e.target.value) }} />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Цена</Form.Label>
              <Form.Control required type="number" placeholder="Цена"
                value={price}
                onChange={e => { setPrice(e.target.value) }} />
            </Form.Group>
            <Form.Group className="mb-3">
              <Form.Label>Кол-во товаров</Form.Label>
              <Form.Control required type="number" placeholder="Кол-во товаров" 
              value={amount}
              onChange={e => { setAmount(e.target.value) }}/>
            </Form.Group>
            <Button className="btn" variant="primary" type="submit">
              Submit
            </Button>
          </Form>
        }
      </Container>
    </>
  )
}

export default Catalog