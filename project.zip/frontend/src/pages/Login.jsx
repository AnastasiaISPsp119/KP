import { useState } from "react"
import { Card, Form, Button, Container } from "react-bootstrap"
import { signin } from "../services/authService"
import { useNavigate } from "react-router";
import styles from "../styles/Auth.module.css"

function Login() {
   // useLoginGuard({ loggedIn: true, path: "/" });
   const navigate = useNavigate();

   const [login, setLogin] = useState('')
   const [password, setPassword] = useState('')

   // TODO: write validation for inputs

   function logIn(event) {
      event.preventDefault();
      event.stopPropagation();

      signin(login, password).then(response => {
            if (response.data.success === false) return alert(response.data.msg)
            
            localStorage.setItem("token", response.data.token)
            return navigate("/")
      })

   }

   return (
      <Container className="d-flex w-100 h-100" style={{ justifyContent: "center" }}>
         <Card style={{ alignSelf: "center" }}>
            <Card.Body>
               <Card.Text>
                  <Form onSubmit={logIn}>
                     <Form.Group className="mb-3" controlId="formBasicUsername">
                        <Form.Label>
                           <h1>
                              Авторизация
                           </h1>
                        </Form.Label>
                        <Form.Control
                           required
                           type="text"
                           placeholder="введите логин"
                           value={login}
                           onChange={e => { setLogin(e.target.value) }} />
                        <Form.Control.Feedback>
                           Please enter a username or email.
                        </Form.Control.Feedback>
                     </Form.Group>

                     <Form.Group className="mb-3" controlId="formBasicPassword">
                        <Form.Control
                           required
                           type="password"
                           placeholder="Введите пароль"
                           value={password}
                           onChange={e => { setPassword(e.target.value) }}
                        />
                        <Form.Control.Feedback type="invalid">
                           Please enter a password.
                        </Form.Control.Feedback>
                     </Form.Group>
                     <Button
                        className={styles.btn}
                        type="submit">
                        Войти
                     </Button>
                  </Form>
               </Card.Text>
            </Card.Body>
         </Card>
      </Container>
   )
}

export default Login