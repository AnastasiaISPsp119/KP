import { useState } from "react"
import { Card, Form, Button, Container } from "react-bootstrap"
import { signup } from "../services/authService"
import { useNavigate } from "react-router";
import styles from "../styles/Auth.module.css"


function Signup() {
   // useLoginGuard({ loggedIn: true, path: "/" });
   const navigate = useNavigate();


   const [username, setUsername] = useState()
   const [email, setEmail] = useState()
   const [password, setPassword] = useState()

   function Signup(event) {
      event.preventDefault();
      event.stopPropagation();

      signup(username, email, password)
         .then(response => {
            if (response.data.success === false) return alert(response.data.msg)
            
            localStorage.setItem("token", response.data.token)
            return navigate("/")
         })


   }
   return (
      <Container className="d-flex w-100 h-100" style={{ justifyContent: "center" }}>
         <Card style={{ alignSelf: "center" }}>
            <Card.Body>
               <Card.Text>
                  <Form onSubmit={Signup}>
                     <Form.Label>
                        <h1>
                           Регистрация
                        </h1>
                     </Form.Label>
                     <Form.Group className="mb-3" controlId="formBasicUsername">
                        <Form.Control
                           type="text"
                           placeholder="Введите логин"
                           onChange={e => { setUsername(e.target.value) }} />
                     </Form.Group>

                     <Form.Group className="mb-3" controlId="formBasicEmail">
                        <Form.Control
                           type="email"
                           placeholder="Введите почту"
                           onChange={e => { setEmail(e.target.value) }}
                        />
                     </Form.Group>
                     <Form.Group className="mb-3" controlId="formBasicPassword">
                        <Form.Control
                           type="password"
                           placeholder="Введите пароль"
                           onChange={e => { setPassword(e.target.value) }}
                        />
                     </Form.Group>
                     <Button
                     className={styles.btn}
                        variant="primary"
                        type="submit"
                     >
                        Зарегистрироваться
                     </Button>
                  </Form>
               </Card.Text>
            </Card.Body>
         </Card>
      </Container>
   )
}

export default Signup