exports.useToken = function () {
   return localStorage.getItem("token")
}